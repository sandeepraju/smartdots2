/*the javascript file used to define the logic of the menu*/
var menuDuration = 300;
